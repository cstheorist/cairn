#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
: "${PYTHON:=python3}"
"$PYTHON" tools/extract_core.py --check
if [ -d .tools/cargo/bin ]; then
    export CARGO_HOME="$PWD/.tools/cargo"
    export RUSTUP_HOME="$PWD/.tools/rustup"
    export PATH="$CARGO_HOME/bin:$PATH"
fi
if [ -z "${VERUS:-}" ]; then
    case "$(uname -s):$(uname -m)" in
        Darwin:arm64) VERUS="$PWD/.tools/verus-arm64-macos/verus" ;;
        Darwin:x86_64) VERUS="$PWD/.tools/verus-x86-macos/verus" ;;
        Linux:x86_64) VERUS="$PWD/.tools/verus-x86-linux/verus" ;;
        *) VERUS=verus ;;
    esac
fi
: "${TLA2TOOLS:=.tools/tla2tools.jar}"
"$VERUS" --crate-type lib verification/core.rs
for model in ShardStore ReplicaEpoch TwoPhaseCommit PredicateLocks ReadBatch VoteCommit LocalFinish VolatileOpen; do
    if [ "${TLC_USE_JAVA:-0}" = 1 ]; then
        java -XX:+UseParallelGC -cp "$TLA2TOOLS" tlc2.TLC -workers 2 -metadir "formal/states/$model" -config "formal/$model.cfg" "formal/$model.tla"
    else
        docker run --rm -v "$PWD:/app" -w /app eclipse-temurin:21-jre java -XX:+UseParallelGC -cp "$TLA2TOOLS" tlc2.TLC -workers 2 -metadir "formal/states/$model" -config "formal/$model.cfg" "formal/$model.tla"
    fi
done
