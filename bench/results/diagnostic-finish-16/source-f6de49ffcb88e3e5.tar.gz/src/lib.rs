pub mod core;
pub(crate) mod expression;
pub(crate) mod mutation;
pub mod pgwire;
pub(crate) mod relational;
pub mod sql;
pub mod storage;
pub mod transaction;

#[derive(Debug)]
pub struct DbError {
    pub code: &'static str,
    pub message: String,
}

impl DbError {
    pub fn new(code: &'static str, message: impl Into<String>) -> Self {
        Self {
            code,
            message: message.into(),
        }
    }
    pub fn unsupported(message: impl Into<String>) -> Self {
        Self::new("0A000", message)
    }
}
impl std::fmt::Display for DbError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}: {}", self.code, self.message)
    }
}
impl std::error::Error for DbError {}
pub type Result<T> = std::result::Result<T, DbError>;
